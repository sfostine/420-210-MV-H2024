package ca.cegepmv.rochepapierciseau;

public class Jouer {

	public static void main(String[] args) {
		JeuRochePapierCiseau jeu = new JeuRochePapierCiseau();
		jeu.demarrerJeu();
	}

}
