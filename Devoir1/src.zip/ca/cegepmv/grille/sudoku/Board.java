package ca.cegepmv.grille.sudoku;

import java.util.Scanner;

public class Board {
    Case[][] cellules;
    public Board(Case[][] cellules){
        this.cellules = cellules;
    }
    
    public void demarrerJeu() {
    	Scanner scan = new Scanner(System.in);
    	int rangee, colonne;
    	
		System.out.println("À n'importe quel moment, vous pouvez taper 0 pour terminer le jeu.\n");

    	while(true) {
    		afficherBoard();
    		
			/*******************************votre code va ici*******************************************/

    		
    		
    		
    		
    		
    		
    		
    	}
    }

    private void afficherBoard(){
		/*******************************votre code va ici*******************************************/

    }
}
