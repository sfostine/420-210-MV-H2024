package ca.cegepmv.rochepapierciseau;

public enum RochePapierCiseau {
	ROCHE,
	PAPIER,
	CISEAU
}
