package ca.cegepmv.rochepapierciseau;

import java.util.Random;
import java.util.Scanner;

public class JeuRochePapierCiseau {
	
	public void demarrerJeu() {
		//tableau d'enum qui contient les 3 valeurs, ROCHE, PAPIER, CISEAU
		//choix = [ROCHE, PAPIER, CISEAU]
		RochePapierCiseau[] choix = RochePapierCiseau.values();
		
		Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        //Ces variables devraient être incrémenté quand c'est l'utilisateur qui a gagné ou quand c'est l'ordinateur
        int pointUtilisateur = 0, pointOrdinateur = 0;
        
        System.out.println("Bienvenue dans le jeu Roche-Papier-Ciseaux!");
		
		for(int nombrePartie = 0; nombrePartie < 5; nombrePartie++) {
			
			/*******************************votre code va ici*******************************************/
			// roche papier sciceaux
			afficherOptions(choix);

			//retour choix utilisateur
			int choixIntUtilisateur = scanner.nextInt();
			//choix de l'ordinateur
			int choixIntOrdinateur = random.nextInt(3);

			// remplacer par le choix de l'utilisateur
			RochePapierCiseau choixUtilisateur = choix[choixIntUtilisateur];

			//remplacer par le choix de l'ordinateur en utilisant random
			RochePapierCiseau choixOrdi = choix[choixIntOrdinateur];
			/* déterminer le gagnant comme suit:
			 * ROCHE et PAPIER => PAPIER gagne
			 * ROCHE et CISEAU => CISEAU gagne
			 * PAPIER et CISEAU = PAPIER gagne
			 */
			int gagnant = determinerGagnant(choixUtilisateur, choixOrdi);
			
			//ajouter du code ici pour incrémenter pointUtilisateur quand c'est l'utilisateur qui a gagné
			//ou incrémenter pointOrdinateur, quand c'est l'ordinateur qui a gagné
			/*******************************votre code va ici*******************************************/

			switch (gagnant){
				case 1:
					pointUtilisateur++;
					break;
				case -1:
					pointOrdinateur++;
					break;
			}
		}
		
		//fermer le scanner à la fin du jeu
		scanner.close();
		
		// Le message final
        System.out.printf("%nVous avez eu %d. L'ordinateur a eu %d points", pointUtilisateur, pointOrdinateur);

	}

	public void afficherOptions(RochePapierCiseau[] choix) {
		for (int i = 1; i <= 3; i++) {
			System.out.printf("%d. %s %n", i, choix[i - 1]);
		}
	}

	/*  Vous devez comparer le choix de l'utilisateur avec celui et l'ordi
	 * si le choix de l'ordi est le même que celui de l'ordi, c'est égalité. Vous affichez "egalité" et la méthode retourne 0
	 * Selon les choix, si l'utilisateur a gagné, vous affichez le message "Vous avez gagné" et la méthode retourne 1
	 * Selon les choix, si l'ordinateur a gagné, vous affichez le message "L'ordinateur a gagné" et la méthode retourne -1
	 * -1 représente que l'ordinateur a gagné
		0 représente égalité
		1 représente que l'utilisateur a gagné
		
		Déterminer le gagnant comme suit:
		 * ROCHE et PAPIER => PAPIER gagne
		 * ROCHE et CISEAU => ROCHE gagne
		 * PAPIER et CISEAU = CISEAU gagne
		 */
	private int determinerGagnant(RochePapierCiseau monChoix, RochePapierCiseau choixOrdi) {
		/*******************************votre code va ici*******************************************/
		System.out.printf("Vous avez choisi %s et l'ordinateur a choisi %s %n",monChoix, choixOrdi);

		if(monChoix == choixOrdi){
			System.out.println("Égalité");
			return 0;
		} else if (monChoix == RochePapierCiseau.ROCHE && choixOrdi == RochePapierCiseau.CISEAU
					|| monChoix == RochePapierCiseau.PAPIER && choixOrdi == RochePapierCiseau.ROCHE
					|| monChoix == RochePapierCiseau.CISEAU && choixOrdi == RochePapierCiseau.PAPIER) {
			System.out.println("Vous avez gagné");
			return 1;
		}
		else {
			System.out.println("L'ordinateur a gagné");
			return -1;
		}
	}

}
