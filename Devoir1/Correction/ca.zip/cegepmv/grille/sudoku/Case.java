package ca.cegepmv.grille.sudoku;

public class Case {
    private String valeur;
    private boolean defaut;

    public Case(String valeur, boolean defaut){
        this.valeur = valeur;
        this.defaut = defaut;
    }

    public String getValeur() {
        return valeur;
    }



    public void setValeur(String valeur) {
		this.valeur = valeur;
	}

	public boolean isDefaut() {
        return defaut;
    }
}
