package ca.cegepmv.grille.sudoku;

import ca.cegepmv.trianglerectangle.Couleur;

import java.util.Scanner;

public class Board {
    Case[][] cellules;
    public Board(Case[][] cellules){
        this.cellules = cellules;
    }
    
    public void demarrerJeu() {
    	Scanner scan = new Scanner(System.in);
    	int rangee, colonne;
    	
		System.out.println("À n'importe quel moment, vous pouvez taper 0 pour terminer le jeu.\n");

    	while(true) {
    		afficherBoard();
    		
			/*******************************votre code va ici*******************************************/

            //Demander à l'utilisateur de rentrer le numero de colonne
            System.out.println("Saisissez un numéro de rangée");
            rangee = scan.nextInt();

            if (rangee == 0) break;

            System.out.println("Saisissez un numéro de colonne");
             colonne = scan.nextInt();
            if (colonne == 0) break;

            System.out.println("Saisissez la valeur de la case");

            String valeur = scan.next();

             if(this.cellules[rangee - 1][colonne - 1].isDefaut()){
                 System.out.println("Désolé, vous ne pouvez pas changer les valeurs de cette case, car c'est une valeur par défaut.");
             }
             else {
                 this.cellules[rangee - 1][colonne - 1].setValeur(valeur);
             }
    	}
    }

    public void afficherBoard(){
        for (int i = 0; i < this.cellules.length; i++) {
            for (int j = 0; j < this.cellules[i].length; j++) {
                Case aCase = this.cellules[i][j];
                if (aCase.isDefaut()){
                    System.out.print(Couleur.BLUE+ aCase.getValeur()+ Couleur.RESET+ "  ");
                }
                else{
                    System.out.print(Couleur.RED+ aCase.getValeur() + Couleur.RESET + "  ");
                }

                if((j+1) % 3 == 0 && j != 0){
                    System.out.print("| ");
                }
            }
            System.out.println();

            if ((i +1) % 3 == 0 && i != 0){
                System.out.println("_______________________________");
            }
        }

        System.out.println();
    }
}
